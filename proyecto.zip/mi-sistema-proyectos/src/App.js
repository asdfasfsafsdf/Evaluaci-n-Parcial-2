import React, { useState, useMemo } from 'react';
import './App.css';

// --- DATOS LOCALES (Mínimo 6 proyectos) ---
const projectsData = [
  {
    id: 1,
    name: "AgroTech Monitor",
    area: "IoT",
    description: "Sistema de sensores para monitoreo de humedad y temperatura en cultivos hidropónicos.",
    status: "En Desarrollo",
    impact: "Alto"
  },
  {
    id: 2,
    name: "EduChat AI",
    area: "IA",
    description: "Asistente virtual basado en LLMs para tutorías personalizadas de matemáticas básicas.",
    status: "Finalizado",
    impact: "Medio"
  },
  {
    id: 3,
    name: "SecureCampus Face",
    area: "Seguridad",
    description: "Control de acceso a laboratorios mediante reconocimiento facial biométrico.",
    status: "Propuesto",
    impact: "Alto"
  },
  {
    id: 4,
    name: "Portal de Matrículas",
    area: "Web",
    description: "Plataforma web reactiva para la gestión de inscripciones y horarios semestrales.",
    status: "Finalizado",
    impact: "Alto"
  },
  {
    id: 5,
    name: "Red Mesh Comunitaria",
    area: "Redes",
    description: "Despliegue de red descentralizada para zonas con baja cobertura de internet.",
    status: "En Desarrollo",
    impact: "Medio"
  },
  {
    id: 6,
    name: "Library AR",
    area: "Software",
    description: "Aplicación móvil de Realidad Aumentada para ubicar libros en la biblioteca física.",
    status: "Finalizado",
    impact: "Bajo"
  }
];

function App() {
  // Estados para filtros
  const [filterArea, setFilterArea] = useState('Todas');
  const [filterStatus, setFilterStatus] = useState('Todos');
  const [sortImpact, setSortImpact] = useState('Ninguno');

  // Referencia para scroll suave
  const catalogRef = React.useRef(null);

  const scrollToCatalog = () => {
    catalogRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // --- LÓGICA DE FILTRADO Y ORDENAMIENTO (Usando useMemo para optimización) ---
  const filteredProjects = useMemo(() => {
    let result = projectsData;

    // 1. Filtrar por Área
    if (filterArea !== 'Todas') {
      result = result.filter(p => p.area === filterArea);
    }

    // 2. Filtrar por Estado
    if (filterStatus !== 'Todos') {
      result = result.filter(p => p.status === filterStatus);
    }

    // 3. Ordenar por Impacto
    if (sortImpact !== 'Ninguno') {
      const impactValues = { "Alto": 3, "Medio": 2, "Bajo": 1 };
      result = [...result].sort((a, b) => {
        if (sortImpact === 'Mayor a Menor') {
          return impactValues[b.impact] - impactValues[a.impact];
        } else {
          return impactValues[a.impact] - impactValues[b.impact];
        }
      });
    }

    return result;
  }, [filterArea, filterStatus, sortImpact]);

  // Función para obtener color según estado
  const getStatusColor = (status) => {
    switch(status) {
      case 'Propuesto': return 'var(--status-propuesto)';
      case 'En Desarrollo': return 'var(--status-desarrollo)';
      case 'Finalizado': return 'var(--status-finalizado)';
      default: return '#999';
    }
  };

  return (
    <div className="app-container">
      
      {/* --- VISTA INFORMATIVA --- */}
      <header>
        <h1>Sistema de Proyectos Tecnológicos</h1>
        <p className="subtitle">Innovación Académica y Desarrollo</p>
        
        <div className="purpose-section">
          <h3>Propósito del Sistema</h3>
          <p>
            Esta plataforma centraliza, organiza y difunde los <strong>proyectos tecnológicos</strong> realizados 
            por nuestra comunidad. Un proyecto tecnológico es una iniciativa que aplica conocimientos científicos 
            y herramientas técnicas para resolver problemas prácticos o crear innovación.
          </p>
          <div className="tech-stack">
            <span className="tech-badge">⚛️ React</span>
            <span className="tech-badge">🔥 Firebase</span>
            <span className="tech-badge">🤖 IA Integration</span>
          </div>
          <button onClick={scrollToCatalog} className="cta-button">
            Explorar Catálogo ▼
          </button>
        </div>
      </header>

      {/* --- CATÁLOGO INTERACTIVO --- */}
      <section ref={catalogRef}>
        <h2>Catálogo Interactivo</h2>
        
        {/* Panel de Control (Filtros) */}
        <div className="filters-container">
          <div>
            <label>Área: </label>
            <select onChange={(e) => setFilterArea(e.target.value)} value={filterArea}>
              <option value="Todas">Todas</option>
              <option value="Software">Software</option>
              <option value="IA">Inteligencia Artificial</option>
              <option value="IoT">Internet of Things</option>
              <option value="Web">Desarrollo Web</option>
              <option value="Redes">Redes</option>
              <option value="Seguridad">Seguridad</option>
            </select>
          </div>

          <div>
            <label>Estado: </label>
            <select onChange={(e) => setFilterStatus(e.target.value)} value={filterStatus}>
              <option value="Todos">Todos</option>
              <option value="Propuesto">Propuesto</option>
              <option value="En Desarrollo">En Desarrollo</option>
              <option value="Finalizado">Finalizado</option>
            </select>
          </div>

          <div>
            <label>Impacto: </label>
            <select onChange={(e) => setSortImpact(e.target.value)} value={sortImpact}>
              <option value="Ninguno">Sin Ordenar</option>
              <option value="Mayor a Menor">Mayor a Menor Impacto</option>
              <option value="Menor a Mayor">Menor a Mayor Impacto</option>
            </select>
          </div>
        </div>

        {/* Listado (Grid) */}
        <div className="projects-grid">
          {filteredProjects.length > 0 ? (
            filteredProjects.map((project) => (
              <article key={project.id} className="project-card">
                <div className="card-header">
                  <span className="area-tag">{project.area}</span>
                  <span 
                    className="status-badge"
                    style={{ backgroundColor: getStatusColor(project.status) }}
                  >
                    {project.status}
                  </span>
                </div>
                <h3>{project.name}</h3>
                <p>{project.description}</p>
                
                <div className="impact-level">
                  <span>Impacto: {project.impact}</span>
                  <div className="impact-bar">
                    <div 
                      className="impact-fill"
                      style={{ width: project.impact === 'Alto' ? '100%' : project.impact === 'Medio' ? '60%' : '30%' }}
                    ></div>
                  </div>
                </div>
              </article>
            ))
          ) : (
            <p style={{ gridColumn: '1 / -1', textAlign: 'center' }}>
              No se encontraron proyectos con esos filtros.
            </p>
          )}
        </div>
      </section>

      <footer style={{ marginTop: '50px', textAlign: 'center', color: '#555', fontSize: '0.8rem' }}>
        © 2024 Sistema de Proyectos - Potenciado por React & Firebase
      </footer>
    </div>
  );
}

export default App;
